<?php
namespace pocketmine\command\defaults;
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\TranslationContainer;
class BanCidCommand extends VanillaCommand {
	
	public function __construct($name){
		parent::__construct("bancid", "Бан игрока по CID");
		$this->setPermission("pocketmine.command.bancid");
	}
	public function execute(CommandSender $sender, $label, array $args) {
        if($sender->hasPermission("pocketmine.command.bancid")) {
		    if(count($args) > 0) {
                $player = $sender->getServer()->getPlayer($args[0]);
			    unset($args[0]);
			    if($player !== null) {
 			        $reason3 = implode(" ", $args);
                    if(strlen($reason3) >= 1){
                      $sender->getServer()->getCIDBans()->addBan($player->getClientId(), $reason3, null, $sender->getName());

                      $player->close("","§l§fТебя забанил по CID админ: §7".$sender->getName()."\n§fПричина: §7".$reason3."");

                     $sender->getServer()->broadcastMessage("§l§fИгрок §7".$player->getName()." §fбыл забанен по CID админом §7".$sender->getName()."\n§fПричина: §7".$reason3);

                    } else return $sender->sendMessage("§l§7Укажите причину!");

                } else return $sender->sendMessage("§l§fИгрок не онлайн или вы ввели не верный ник.");

		    } else return $sender->sendMessage("§l§fИспользуйте: §7/bancid <ник> <причина>");
		}
	}
}
?>