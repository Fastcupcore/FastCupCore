<?php
namespace pocketmine\command\defaults;
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\TranslationContainer;
class PardonCommand extends VanillaCommand {
	public function __construct($name){
		parent::__construct("pardon", "Разбанить игрока по нику");
		$this->setPermission("pocketmine.command.unban.player");
	}
	public function execute(CommandSender $sender, $alias, array $args) {
        if($sender->hasPermission("pocketmine.command.unban.player")) {
	        if(count($args) > 0) {
		        $player = $args[0];
		        unset($args[0]);
		        $reason4 = implode(" ", $args);
			    if(strlen($reason4) >= 1) {
				    $sender->getServer()->getNameBans()->remove($player);

$sender->getServer()->broadcastMessage("§l§fИгрок §7".$player." §fбыл разбанен §7".$sender->getName()."\n§fПричина разбана: §7".$reason4);

				} else return $sender->sendMessage("§l§fУкажите причину разбана!");
				
			} else return $sender->sendMessage("§l§fИспользуйте: §7/pardon <ник> <причина разбана>");
		}
	}
}
?>