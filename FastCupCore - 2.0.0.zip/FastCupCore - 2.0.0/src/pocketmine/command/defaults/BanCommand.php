<?php
namespace pocketmine\command\defaults;
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
class BanCommand extends VanillaCommand {
	
	public function __construct($name){
		parent::__construct("ban", "Бан игрока по нику");
		$this->setPermission("pocketmine.command.ban.player");
	}

	public function execute(CommandSender $sender, $label, array $args) {
        if($sender->hasPermission("pocketmine.command.ban.player")) {
		    if(count($args) > 0) {
                $player = $sender->getServer()->getPlayer($args[0]);
			    if($player != null) {
		            unset($args[0]);
 		            $reason1 = implode(" ", $args);
                    if(strlen($reason1) >= 1){
                        $sender->getServer()->getNameBans()->addBan($player->getName(), $reason1, null, $sender->getName());

$player->close("","§l§fТебя забанил игрок §7".$sender->getName()."\n§fПричина: §7".$reason1."");

$sender->getServer()->broadcastMessage("§l§fИгрок §7".$player->getName()." §fбыл забанен админом §7".$sender->getName()."\n§fПричина: §7".$reason1);

                    } else return $sender->sendMessage("§l§7Укажите причину!");

			    } else return $sender->sendMessage("§l§7Игрок не онлайн или вы ввел и не верный ник.");
			    
	        } else return $sender->sendMessage("§l§fИспользуйте §7/ban <ник> <причина>");
		}
	}
}