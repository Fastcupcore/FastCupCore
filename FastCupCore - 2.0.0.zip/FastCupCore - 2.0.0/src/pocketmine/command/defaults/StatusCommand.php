<?php
namespace pocketmine\command\defaults;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;
class StatusCommand extends VanillaCommand {
	public function __construct($name){
		parent::__construct("status", "Отображает производительность сервера");
		$this->setPermission("pocketmine.command.status");
	}
	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}
		$mUsage = Utils::getMemoryUsage(true);
		$rUsage = Utils::getRealMemoryUsage();
		$server = $sender->getServer();
		$onlineCount = 0;
		foreach($sender->getServer()->getOnlinePlayers() as $player){
			if($player->isOnline() and (!($sender instanceof Player) or $sender->canSee($player))){
				++$onlineCount;
			}
		}
		$sender->sendMessage("---- ". TextFormat::RESET ."%pocketmine.command.status.title". TextFormat::RESET ." ----");
		$sender->sendMessage("%pocketmine.command.status.player" . TextFormat::RESET . " " . $onlineCount . "/" . $sender->getServer()->getMaxPlayers());
		$sender->sendMessage("%pocketmine.command.status.uptime " . TextFormat::RESET . $sender->getServer()->getUptime());
		$tpsColor = TextFormat::RESET;
		if($server->getTicksPerSecondAverage() < 10){
			$tpsColor = TextFormat::RESET;
		}elseif($server->getTicksPerSecondAverage() < 1){
			$tpsColor = TextFormat::RESET;
		}
		$tpsColour = TextFormat::RESET;
		if($server->getTicksPerSecond() < 10){
			$tpsColour = TextFormat::RESET;
		}elseif($server->getTicksPerSecond() < 1){
			$tpsColour = TextFormat::RESET;
		}
		$sender->sendMessage("%pocketmine.command.status.AverageTPS " . TextFormat::RESET . $server->getTicksPerSecondAverage() . " (" . $server->getTickUsageAverage() . "%)");
		$sender->sendMessage("%pocketmine.command.status.CurrentTPS " . TextFormat::RESET . $server->getTicksPerSecond() . " (" . $server->getTickUsage() . "%)");
		$sender->sendMessage("%pocketmine.command.status.Networkupload " . TextFormat::RESET . \round($server->getNetwork()->getUpload() / 1024, 2) . " kB/s");
		$sender->sendMessage("%pocketmine.command.status.Networkdownload " . TextFormat::RESET . \round($server->getNetwork()->getDownload() / 1024, 2) . " kB/s");
		$sender->sendMessage("%pocketmine.command.status.Threadcount " . TextFormat::RESET . Utils::getThreadCount());
		$sender->sendMessage("%pocketmine.command.status.Mainmemory " . TextFormat::RESET . number_format(round(($mUsage[0] / 1024) / 1024, 2)) . " MB.");
		$sender->sendMessage("%pocketmine.command.status.Totalmemory " . TextFormat::RESET . number_format(round(($mUsage[1] / 1024) / 1024, 2)) . " MB.");
		$sender->sendMessage("%pocketmine.command.status.Totalvirtualmemory " . TextFormat::RESET . number_format(round(($mUsage[2] / 1024) / 1024, 2)) . " MB.");
		$sender->sendMessage("%pocketmine.command.status.Maxmemorysystem " . TextFormat::RESET . number_format(round(($mUsage[2] / 1024) / 1024, 2)) . " MB.");
		if($server->getProperty("memory.global-limit") > 0){
			$sender->sendMessage(TextFormat::RESET . "%pocketmine.command.status.Maxmemorymanager " . TextFormat::RESET . number_format(round($server->getProperty("memory.global-limit"), 2)) . " MB.");
		}
		foreach($server->getLevels() as $level){
			$levelName = $level->getFolderName() !== $level->getName() ? " (" . $level->getName() . ")" : "";
			$timeColor = $level->getTickRateTime() > 40 ? TextFormat::RESET : TextFormat::RESET;
			$sender->sendMessage(TextFormat::RESET . "Мир \"{$level->getFolderName()}\"$levelName: " .
				TextFormat::RESET . number_format(count($level->getChunks())) . TextFormat::RESET . " %pocketmine.command.status.chunks " .
				TextFormat::RESET . number_format(count($level->getEntities())) . TextFormat::RESET . " %pocketmine.command.status.entities " .
				TextFormat::RESET . number_format(count($level->getTiles())) . TextFormat::RESET . " %pocketmine.command.status.tiles " .
				"%pocketmine.command.status.Time " . round($level->getTickRateTime(), 2) . "ms"
			);
		}
		return true;
	}
}
?>