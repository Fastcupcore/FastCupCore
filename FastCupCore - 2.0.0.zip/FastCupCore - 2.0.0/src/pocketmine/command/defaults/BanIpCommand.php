<?php
namespace pocketmine\command\defaults;
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
class BanIpCommand extends VanillaCommand {
	public function __construct($name){
		parent::__construct("ban-ip", "Бан игрока по IP");
		$this->setPermission("pocketmine.command.ban.ip");
	}
	public function execute(CommandSender $sender, $label, array $args) {
        if($sender->hasPermission("pocketmine.command.ban.ip")) {
		    if(count($args) > 0) {
                $player = $sender->getServer()->getPlayer($args[0]);
			    unset($args[0]);
			    $reason2 = implode(" ", $args);
			    if($player !== null) {
                    if(strlen($reason2) >= 1){
                        $sender->getServer()->getIPBans()->addBan($player->getAddress(), $reason2, null, $sender->getName());

$player->close("","§l§fТебя забанил по IP §7".$sender->getName()."\n§fПричина: §7".$reason2."");

$sender->getServer()->broadcastMessage("§l§fИгрок §7".$player->getName()." §fбыл забанен по IP админом §7".$sender->getName()."\n§fПричина: §7".$reason2);

                    } else return $sender->sendMessage("§l§7Укажите причину!");

                }else return $sender->sendMessage("§l§7Игрок не онлайн или вы ввели не верный ник.");

			} else return $sender->sendMessage("§l§fИспользуйте: §7/ban-ip <ник> <причина>");
		}
  	}
}
?>