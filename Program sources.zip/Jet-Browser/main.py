from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWidgets import QShortcut
from PyQt5.QtGui import QKeySequence
from PyQt5 import QtCore, QtWidgets, QtWebEngineWidgets

import os
import sys

class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        self.setCentralWidget(self.tabs)

        navtb = QToolBar("Navigation")
        navtb.setIconSize(QSize(18, 18))
        navtb.setAllowedAreas(Qt.TopToolBarArea)
        navtb.setFloatable(True)
        navtb.setMovable(True)
        self.addToolBar(navtb)

        back_btn = QAction(QIcon(os.path.join('data/images', 'arrow-180.png')), "Back", self)
        back_btn.setStatusTip("Back to previous page")
        back_btn.triggered.connect(lambda: self.tabs.currentWidget().back())
        navtb.addAction(back_btn)

        next_btn = QAction(QIcon(os.path.join('data/images', 'arrow-000.png')), "Forward", self)
        next_btn.setStatusTip("Forward to next page")
        next_btn.triggered.connect(lambda: self.tabs.currentWidget().forward())
        navtb.addAction(next_btn)

        reload_btn = QAction(QIcon(os.path.join('data/images', 'arrow-circle-315.png')), "reload", self)
        reload_btn.setStatusTip("reload page")
        reload_btn.triggered.connect(lambda: self.tabs.currentWidget().reload())
        navtb.addAction(reload_btn)

        stop_btn = QAction(QIcon(os.path.join('data/images', 'cross-circle.png')), "Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        stop_btn.triggered.connect(lambda: self.tabs.currentWidget().stop())
        navtb.addAction(stop_btn)

        navtb.addSeparator()

        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        navtb.addSeparator()

        home_btn = QAction(QIcon(os.path.join('data/images', 'home.png')), "Home", self)
        home_btn.setStatusTip("Go Home")
      
        home_btn.triggered.connect(lambda: self.tabs.tabBar().show())
        home_btn.triggered.connect(lambda: self.showMaximized())
        home_btn.triggered.connect(lambda: self.add_new_tab())
        
        navtb.addAction(home_btn)
        
        new_tab_action = QAction(QIcon(os.path.join('data/images', 'new-page.png')), "New Tab", self)
        new_tab_action.setStatusTip("Open new tab")
        new_tab_action.triggered.connect(lambda: self.tabs.tabBar().show())
        new_tab_action.triggered.connect(lambda: self.showMaximized())
        new_tab_action.triggered.connect(lambda: self.get_add_new_tab())
        navtb.addAction(new_tab_action)

        self.httpsicon = QLabel()
        self.httpsicon.setPixmap(QPixmap(os.path.join('data/images', 'lock-nossl.png')))
        navtb.addWidget(self.httpsicon)
        
        self.add_new_tab(QUrl('https://google.com/'), 'Homepage')

        '''Shortcuts'''

        self.shortcut_open = QShortcut(QKeySequence('F5'), self)
        self.shortcut_open.activated.connect(lambda: sys.exit())
        
        self.shortcut_open = QShortcut(QKeySequence('TAB'), self)
        self.shortcut_open.activated.connect(lambda: self.add_new_tab())
        
        self.shortcut_open = QShortcut(QKeySequence('ESC'), self)
        self.shortcut_open.activated.connect(lambda: self.tabs.currentWidget().reload())

        self.show()

        self.setWindowIcon(QIcon(os.path.join('data/images', 'icon.png')))

    @QtCore.pyqtSlot()
    def loadStartedHandler(self):
        print()

    @QtCore.pyqtSlot(int)
    def loadProgressHandler(self, prog):
        print()

    @QtCore.pyqtSlot()
    def loadFinishedHandler(self):
        print()

    @QtCore.pyqtSlot("QWebEngineDownloadItem*")
    def on_downloadRequested(self, download):
        old_path = download.url().path()  # download.path()
        suffix = QtCore.QFileInfo(old_path).suffix()
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save File", old_path, "*." + suffix
        )
        if path:
            download.setPath(path)
            download.accept()
    def handle_fullscreen_requested(self, request, browser):
        request.accept()

        if request.toggleOn():
            self.showFullScreen()
            self.tabs.tabBar().hide()
        else:
            self.showMaximized()
            self.tabs.tabBar().show()

    def bookmarks(self):
        pass

    def mycontextMenuEvent(self, event):
        url = 'view-source:' + self.urlbar.text()
        menu = QtWidgets.QMenu(self)
        reloadAction = menu.addAction(QIcon(os.path.join('data/images', 'arrow-circle-315.png')), "Reload page")
        reloadAction.triggered.connect(lambda: self.tabs.currentWidget().reload())

        innewtabAction = menu.addAction(QIcon(os.path.join('data/images', 'ui-tab--plus.png')), "Open in new tab")
        innewtabAction.triggered.connect(lambda: self.add_new_tab())

        sourceAction = menu.addAction(QIcon(os.path.join('data/images', 'page-source.png')), "View page source")
        sourceAction.triggered.connect(lambda: self.add_new_tab(qurl=QUrl(url)))
        menu.exec_(event.globalPos())

    def actionClicked(self, checked):
        action = self.sender()
        print(action.text())
        print(action.data())

    def add_new_tab(self, qurl=None, label="Blank"):

        if qurl is None:
            qurl = QUrl("http://google.com/")

        browser = QWebEngineView()
        browser.settings().setAttribute(QWebEngineSettings.ScrollAnimatorEnabled, True)
        browser.settings().setAttribute(QWebEngineSettings.FullScreenSupportEnabled, True)
        browser.page().fullScreenRequested.connect(lambda request: request.accept())
        browser.setUrl(qurl)
        QtWebEngineWidgets.QWebEngineProfile.defaultProfile().downloadRequested.connect(
            self.on_downloadRequested
        )

        browser.loadStarted.connect(self.loadStartedHandler)
        browser.loadProgress.connect(self.loadProgressHandler)
        browser.loadFinished.connect(self.loadFinishedHandler)

        browser.contextMenuEvent = self.mycontextMenuEvent
        i = self.tabs.addTab(browser, label)

        self.tabs.setCurrentIndex(i)

        browser.urlChanged.connect(lambda qurl, browser=browser:
                                   self.update_urlbar(qurl, browser))
        browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                     self.tabs.setTabText(i, browser.page().title()))
        browser.page().fullScreenRequested.connect(
            lambda request, browser=browser: self.handle_fullscreen_requested(
                request, browser
            )
        )

    def get_add_new_tab(self, qurl=None, label="Blank"):

        if qurl is None:
            qurl = QUrl("/")

        browser = QWebEngineView()
        browser.settings().setAttribute(QWebEngineSettings.ScrollAnimatorEnabled, True)
        browser.settings().setAttribute(QWebEngineSettings.FullScreenSupportEnabled, True)
        browser.page().fullScreenRequested.connect(lambda request: request.accept())
        browser.setUrl(qurl)
        QtWebEngineWidgets.QWebEngineProfile.defaultProfile().downloadRequested.connect(
            self.on_downloadRequested
        )

        browser.loadStarted.connect(self.loadStartedHandler)
        browser.loadProgress.connect(self.loadProgressHandler)
        browser.loadFinished.connect(self.loadFinishedHandler)

        browser.contextMenuEvent = self.mycontextMenuEvent
        i = self.tabs.addTab(browser, label)

        self.tabs.setCurrentIndex(i)

        browser.urlChanged.connect(lambda qurl, browser=browser:
                                   self.update_urlbar(qurl, browser))
        browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                     self.tabs.setTabText(i, browser.page().title()))
        browser.page().fullScreenRequested.connect(
            lambda request, browser=browser: self.handle_fullscreen_requested(
                request, browser
            )
        )

    def tab_open_doubleclick(self, i):
        if i == -1:
            self.add_new_tab()

    def current_tab_changed(self, i):
        qurl = self.tabs.currentWidget().url()
        self.update_urlbar(qurl, self.tabs.currentWidget())
        self.update_title(self.tabs.currentWidget())

    def close_current_tab(self, i):
        if self.tabs.count() < 2:
            return

        self.tabs.removeTab(i)

    def view(self):
        url = self.urlbar.text()
        url = f"view-source:{url}"
        self.tabs.currentWidget().setUrl(QUrl(url))

    def update_title(self, browser):
        if browser != self.tabs.currentWidget():
            return

        title = self.tabs.currentWidget().page().title()
        self.setWindowTitle("%s Jet Browser" % title)

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        if q.scheme() == "":
            q.setScheme(None)
        self.tabs.currentWidget().setUrl(q)

    def update_urlbar(self, q, browser=None):

        if browser != self.tabs.currentWidget():
            return

        if q.scheme() == 'https':
            self.httpsicon.setPixmap(QPixmap(os.path.join('data/images', 'lock-ssl.png')))
        else:
            self.httpsicon.setPixmap(QPixmap(os.path.join('data/images', 'lock-nossl.png')))

        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(999)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName("Jet Browser")
    window = MainWindow()
    window.showMaximized()
    sys.exit(app.exec_())