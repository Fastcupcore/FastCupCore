<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\entity;

use pocketmine\event\entity\EntityCombustByEntityEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\level\Level;
use pocketmine\level\MovingObjectPosition;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\math\VoxelRayTrace;
use pocketmine\block\Block;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\Player;
use pocketmine\Server;

abstract class Projectile extends Entity
{

    const DATA_SHOOTER_ID = 17;

    protected $damage = 0;

    protected $shootingEntity;

    public $hadCollision = false;
    /** @var Vector3|null */
    protected $blockHit;
    /** @var int|null */
    protected $blockHitId;
    /** @var int|null */
    protected $blockHitData;

    public function __construct(Level $level, CompoundTag $nbt, Entity $shootingEntity = null)
    {
        if ($shootingEntity !== null) {
            $this->setOwningEntity($shootingEntity);
            $this->shootingEntity = $shootingEntity;
        }
        parent::__construct($level, $nbt);
    }

    public function getShootingEntity()
    {
        return $this->shootingEntity;
    }

    public function setShootingEntity(Entity $entity)
    {
        $this->setOwningEntity($entity);
        $this->shootingEntity = $entity;
    }

    public function attack($damage, EntityDamageEvent $source)
    {
        if ($source->getCause() === EntityDamageEvent::CAUSE_VOID) {
            parent::attack($damage, $source);
        }
    }

    protected function initEntity()
    {
        parent::initEntity();

        $this->setMaxHealth(1);
        $this->setHealth(1);
    }

    public function canCollideWith(Entity $entity)
    {
        return $entity instanceof Living and !$this->onGround and !($entity instanceof Player and $entity->isSpectator());
    }

    /**
     * Returns the amount of damage this projectile will deal to the entity it hits.
     * @return int
     */
    public function getResultDamage(): int
    {
        return (int)ceil(sqrt($this->motionX ** 2 + $this->motionY ** 2 + $this->motionZ ** 2) * $this->damage);
    }

    public function onCollideWithEntity(Entity $entity)
    {
        if ($entity instanceof Player and $entity->isSpectator()) {
            return;
        }

        $this->server->getPluginManager()->callEvent(new ProjectileHitEvent($this));

        $damage = $this->getResultDamage();

        if ($this->getOwningEntity() === null) {
            $ev = new EntityDamageByEntityEvent($this, $entity, EntityDamageEvent::CAUSE_PROJECTILE, $damage);
        } else {
            $ev = new EntityDamageByChildEntityEvent($this->getOwningEntity(), $this, $entity, EntityDamageEvent::CAUSE_PROJECTILE, $damage);
        }

        $entity->attack($ev->getFinalDamage(), $ev);

        $this->hadCollision = true;

        if ($this->fireTicks > 0) {
            $ev = new EntityCombustByEntityEvent($this, $entity, 5);
            $this->server->getPluginManager()->callEvent($ev);
            if (!$ev->isCancelled()) {
                $entity->setOnFire($ev->getDuration());
            }
        }

        $this->kill();
    }

    public function saveNBT()
    {
    }

    public function onUpdate($currentTick)
    {
        if ($this->closed) {
            return false;
        }
        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0 and !$this->justCreated) {
            return true;
        }
        $this->lastUpdate = $currentTick;
        $hasUpdate = $this->entityBaseTick($tickDiff);
        if ($this->isAlive()) {
            if (!$this->isCollided) {
                $this->motionY -= $this->gravity;
            }
            $hasUpdate = $this->move($this->motionX, $this->motionY, $this->motionZ);
        }
        return $hasUpdate;
    }

    public function move($dx, $dy, $dz)
    {
        if ($dx === 0 && $dy === 0 && $dz === 0) {
            return false;
        }
        $this->blocksAround = null;

        $start = $this->asVector3();
        $end = $start->add($dx, $dy, $dz);

        $directionVector = (clone $end)->subtract(clone $start)->normalize();
        if ($directionVector->lengthSquared() <= 0) {
            return false;
        }

        $blockHit = null;
        $entityHit = null;
        $hitResult = null;

        foreach (VoxelRayTrace::betweenPoints($start, $end, $directionVector) as $vector3) {
            $block = $this->level->getBlock(new Vector3($vector3->x, $vector3->y, $vector3->z));
            if ($block->getId() === Block::AIR) {
                continue;
            }

            $blockHitResult = $this->calculateInterceptWithBlock($block, $start, $end);
            if ($blockHitResult !== null) {
                $end = $blockHitResult->hitVector;
                $blockHit = $block;
                $hitResult = $blockHitResult;
                break;
            }
        }

        if ($hitResult === null) {
            $nearEntity = null;
            $entityDistance = PHP_INT_MAX;
            $movingObjectPosition = null;
            $newDiff = $end->subtract($start);
            foreach($this->level->getCollidingEntities($this->boundingBox->addCoord($newDiff->x, $newDiff->y, $newDiff->z)->expand(1, 1, 1), $this) as $entity){
                if($entity->getId() === $this->getOwningEntityId() and $this->ticksLived < 5){
                    continue;
                }
                $entityBB = $entity->boundingBox->expandedCopy(0.3, 0.3, 0.3);
                $entityHitResult = $entityBB->calculateIntercept($start, $end);
                if($entityHitResult === null){
                    continue;
                }
                $distance = $this->distanceSquared($entityHitResult->hitVector);
                if($distance < $entityDistance){
                    $entityDistance = $distance;
                    $entityHit = $entity;
                    $hitResult = $entityHitResult;
                    $end = $entityHitResult->hitVector;
                }
            }
        }

        $this->x = $end->x;
        $this->y = $end->y;
        $this->z = $end->z;
        $this->recalculateBoundingBox();

        if ($hitResult != null) {
            if ($blockHit != null){
                $this->onHitBlock($blockHit);
            } elseif ($entityHit != null){
                $this->onCollideWithEntity($entityHit);
            }
            $this->isCollided = $this->onGround = true;
            $this->motionX = $this->motionY = $this->motionZ = 0;
            $res = false;
        } else {
            $this->isCollided = $this->onGround = false;
            $this->blockHit = $this->blockHitId = $this->blockHitData = null;
            $f = sqrt(($this->motionX ** 2) + ($this->motionZ ** 2));
            $this->yaw = (atan2($this->motionX, $this->motionZ) * 180 / M_PI);
            $this->pitch = (atan2($this->motionY, $f) * 180 / M_PI);
            $res = true;
        }
        $this->checkChunks();
        $this->checkBlockCollision();
        $this->updateMovement();
        return $res;
    }

    /**
     * Called by move() when raytracing blocks to discover whether the block should be considered as a point of impact.
     * This can be overridden by other projectiles to allow altering the blocks which are collided with (for example
     * some projectiles collide with any non-air block).
     *
     * @param Block $block
     * @param Vector3 $start
     * @param Vector3 $end
     *
     * @return RayTraceResult|null the result of the ray trace if successful, or null if no interception is found.
     */
    protected function calculateInterceptWithBlock(Block $block, Vector3 $start, Vector3 $end): ?RayTraceResult
    {
        return $block->calculateIntercept2($start, $end);
    }

    /**
     * Called when the projectile collides with a Block.
     * Then entity will remove.
     *
     * @param Block $blockHit
     */
    protected function onHitBlock(Block $blockHit): void
    {
        $this->blockHit = $blockHit->asVector3();
        $this->blockHitId = $blockHit->getId();
        $this->blockHitData = $blockHit->getDamage();
        $this->server->getPluginManager()->callEvent(new ProjectileHitEvent($this));
    }

    protected function recalculateBoundingBox(): void
    {
        $halfWidth = $this->width / 2;
        $this->boundingBox->setBounds(
            $this->x - $halfWidth,
            $this->y,
            $this->z - $halfWidth,
            $this->x + $halfWidth,
            $this->y + $this->height,
            $this->z + $halfWidth
        );
    }
}